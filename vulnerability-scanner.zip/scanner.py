import socket
import threading

# Function to scan a single port
def scan_port(target, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect((target, port))
        print(f"[+] Port {port} is open")
        s.close()
    except:
        pass

# Main function
def main():
    target = input("Enter the IP or Host to scan: ")
    ports = [21, 22, 23, 25, 53, 80, 110, 135, 139, 443, 445, 8080]

    print(f"Scanning target: {target}")

    for port in ports:
        thread = threading.Thread(target=scan_port, args=(target, port))
        thread.start()

if __name__ == "__main__":
    main()
