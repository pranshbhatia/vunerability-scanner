# Basic Vulnerability Scanner

A simple Python-based network scanner to identify open ports on a target system.

## Features:
- Scans common ports (21, 22, 23, 25, 53, 80, 110, 135, 139, 443, 445, 8080)
- Multithreaded scanning for faster results
- Useful for basic vulnerability assessment

## How to Run:
1. Run the script:
```
python scanner.py
```

2. Enter the target IP or hostname when prompted.

## Example Output:
```
Scanning target: 192.168.1.1
[+] Port 22 is open
[+] Port 80 is open
```

## Notes:
- This is a basic educational scanner; for advanced scanning use professional tools like Nmap.
